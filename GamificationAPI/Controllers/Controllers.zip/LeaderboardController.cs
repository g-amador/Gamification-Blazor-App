﻿using GamificationApi.Models.Context;
using Microsoft.AspNetCore.Mvc;

namespace GamificationAPI.Controllers
{
    /// <summary>
    /// The leaderboard return the list of the best players of an application.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class LeaderboardController : ControllerBase
    {
        private readonly PlayerContext _context;

        public LeaderboardController(PlayerContext context)
        {
            _context = context;
        }

        /*
        /// <summary>
        /// Get LeaderBoard. 
        /// </summary>
        /// <returns>The list of the five's best players of an application order by points.</returns>
        // GET: api/Badges
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Player>>> GetPlayerItems()
        {
            //TODO: implement method
            return await _context.PlayerItems.ToListAsync();
        }
        */
    }
}

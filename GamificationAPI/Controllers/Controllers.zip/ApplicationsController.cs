﻿using GamificationApi.Models;
using GamificationApi.Models.Context;
using GamificationApi.Models.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GamificationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicationsController : ControllerBase
    {
        private readonly ApplicationContext _applicationContext;

        public ApplicationsController(ApplicationContext applicationContext)
        {
            _applicationContext = applicationContext;
        }        

        /// <summary>
        /// Get application.
        /// 
        /// You must provide the apiKey and apiPassword in the http header.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <returns>The name, description and the key of an application.</returns>
        // GET: api/Applications/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ApplicationDTO>> GetApplication(long id, [FromHeader] string apiKey, [FromHeader] string apiSecret)
        {
            var application = await _applicationContext.ApplicationItems.FindAsync(id);
            
            if (application == null)
            {
                return NotFound();
            }

            if (application.ApiKey != apiKey || application.ApiSecret != apiSecret)
            {
                return BadRequest();
            }                    

            return ApplicationToDTO(application);
        }

        /// <summary>
        /// Update application information.
        /// 
        /// You can update all informations of your application (including apiKey and apiPassword).
        /// </summary>
        /// <param name="id"></param>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <param name="application"></param>
        /// <returns></returns>
        // PUT: api/Applications/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutApplication(long id, [FromHeader] string apiKey, [FromHeader] string apiSecret, Application application)
        {
            if (id != application.Id)
            {
                return BadRequest();
            }
            
            bool isNotUniqueApiKey = await _applicationContext.ApplicationItems.AnyAsync(a => a.Id != id && a.ApiKey == apiKey);
            bool isNotAuthToModify = await _applicationContext.ApplicationItems.AnyAsync(a => a.Id == id && (a.ApiKey != apiKey || a.ApiSecret != apiSecret));
            if (isNotUniqueApiKey || isNotAuthToModify) 
            {
                return BadRequest();
            }

            /*
            foreach (Badge b in application.Badges)
            {
                b.Application = application;
            }
            foreach (Event e in application.Events)
            {
                e.Application = application;
            }
            foreach (Player p in application.Players)
            {
                p.Application = application;
            }
            foreach (Rule r in application.Rules)
            {
                r.Application = application;
            }
            */

            _applicationContext.Entry(application).State = EntityState.Modified;

            try
            {
                await _applicationContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!ApplicationExists(id))
            {
                return NotFound();                
            }

            return Ok();
        }

        /// <summary>
        /// Create a new application.
        /// 
        /// This is the first thing you must do to use this API. Give a name, a description and a unique key and a secure password. 
        /// </summary>
        /// <param name="application"></param>
        /// <returns>The application id.</returns>
        // POST: api/Applications
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<String>> PostApplication(Application application)
        {
            bool isNotUniqueApiKey = await _applicationContext.ApplicationItems.AnyAsync(a => a.ApiKey == application.ApiKey);
            if (isNotUniqueApiKey)
            {
                return BadRequest();
            }

            _applicationContext.ApplicationItems.Add(application);
            await _applicationContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetApplication), new { id = application.Id }, new { Status ="created", url ="/application/" + application.Id });
        }

        /// <summary>
        /// Delete an application.
        /// 
        /// Be careful, when an application is deleted, all the attach resources are deleted in cascade!
        /// </summary>
        /// <param name="id"></param>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <returns></returns>
        // DELETE: api/Applications/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteApplication(long id, [FromHeader] string apiKey, [FromHeader] string apiSecret)
        {
            var application = await _applicationContext.ApplicationItems.FindAsync(id);
            if (application == null)
            {
                return NotFound();
            }

            if (application.ApiKey != apiKey || application.ApiSecret != apiSecret)
            {
                return BadRequest();
            }

            /*
            application.Badges.Clear();
            application.Events.Clear();
            application.Players.Clear();
            application.Rules.Clear();
            */

            _applicationContext.ApplicationItems.Remove(application);
            await _applicationContext.SaveChangesAsync();
            
            return Ok();
        }

        private bool ApplicationExists(long id) =>
            _applicationContext.ApplicationItems.Any(a => a.Id == id);

        private static ApplicationDTO ApplicationToDTO(Application applicationItem) =>
            new ApplicationDTO
            {
                Name = applicationItem.Name,
                Description = applicationItem.Description,
                ApiKey = applicationItem.ApiKey
            };
        }
}

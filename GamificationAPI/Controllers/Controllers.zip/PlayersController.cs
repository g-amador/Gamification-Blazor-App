﻿using GamificationApi.Models;
using GamificationApi.Models.Context;
using GamificationApi.Models.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GamificationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayersController : ControllerBase
    {
        private readonly PlayerContext _playerContext;

        public PlayersController(PlayerContext playerContext)
        {
            _playerContext = playerContext;
        }


        /// <summary>
        /// Get list of players.
        /// </summary>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <returns>The list of all players of an application.</returns>
        // GET: api/Players
        [HttpGet]
        //public async Task<ActionResult<IEnumerable<PlayerDTO>>> GetPlayerItems([FromHeader] string apiKey, [FromHeader] string apiSecret)
        public async Task<ActionResult<IEnumerable<Player>>> GetPlayerItems([FromHeader] string apiKey, [FromHeader] string apiSecret)
        {
            return await _playerContext.PlayerItems.Where(p => p.Application.ApiKey == apiKey && p.Application.ApiSecret == apiSecret).ToListAsync();                        
            //var result = await _playerContext.PlayerItems.Where(p => p.Application.ApiKey == apiKey && p.Application.ApiSecret == apiSecret).ToListAsync();
            //return result.Select(p => PlayerToDTO(p)).ToList();
        }

        /// <summary>
        /// Get player details.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <returns>The detail of a player, including the numberOfPoints and list of all his badges</returns>
        // GET: api/Players/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PlayerDTO>> GetPlayer(long id, [FromHeader] string apiKey, [FromHeader] string apiSecret)
        {
            var player = await _playerContext.PlayerItems.FindAsync(id);

            if (player == null)
            {
                return NotFound();
            }

            if (player.Application.ApiKey != apiKey || player.Application.ApiSecret != apiSecret)
            {
                return BadRequest();
            }

            return PlayerToDTO(player);
        }

        /// <summary>
        /// Update player information.
        /// 
        /// Update basic informations of a player. The points and badges can only be updated by events.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <param name="player"></param>
        /// <returns></returns>
        // PUT: api/Players/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPlayer(long id, [FromHeader] string apiKey, [FromHeader] string apiSecret, Player player)
        {
            if ((id != player.Id) ||
                (player.Application.ApiKey != apiKey || player.Application.ApiSecret != apiSecret))
            {
                return BadRequest();
            }

            _playerContext.Entry(player).State = EntityState.Modified;

            try
            {
                await _playerContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!PlayerExists(id))
            {
                return NotFound();
            }

            return Ok();
        }

        /// <summary>
        /// Add a new player.
        /// 
        /// Create a new player with his basic informations. To manage points and badges, please go to events resources
        /// </summary>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <param name="player"></param>
        /// <returns>The new player's id.</returns>
        // POST: api/Players
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Player>> PostPlayer([FromHeader] string apiKey, [FromHeader] string apiSecret, Player player)
        {
            bool isNotUniqueEmail = await _playerContext.PlayerItems.AnyAsync(p => p.Email == player.Email);
            if (isNotUniqueEmail)
            {
                return BadRequest();
            }

            //TODO: validate application exsits
            /*player.Application = new Application
            {
                ApiKey = apiKey,
                ApiSecret = apiSecret
            };*/
            /*try
            {
                player.Application = await _playerContext.ApplicationItems.FirstAsync(a => a.ApiKey == apiKey && a.ApiSecret == apiSecret);
            }
            catch {
                return BadRequest();
            }*/

            _playerContext.PlayerItems.Add(player);
            await _playerContext.SaveChangesAsync();

            return CreatedAtAction("GetPlayer", new { id = player.Id }, new { Status ="created", url ="/player/" + player.Id });
        }

        /// <summary>
        /// Delete a player
        /// 
        /// Delete a player, all events link to a player will be deleted in cascade.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="apiKey"></param>
        /// <param name="apiSecret"></param>
        /// <returns></returns>
        // DELETE: api/Players/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Player>> DeletePlayer(long id, [FromHeader] string apiKey, [FromHeader] string apiSecret)
        {
            var player = await _playerContext.PlayerItems.FindAsync(id);
            if (player == null)
            {
                return NotFound();
            }

            if (player.Application.ApiKey != apiKey || player.Application.ApiSecret != apiSecret)
            {
                return BadRequest();
            }

            player.Badges.Clear();

            _playerContext.PlayerItems.Remove(player);
            await _playerContext.SaveChangesAsync();

            return player;
        }

        private bool PlayerExists(long id)
        {
            return _playerContext.PlayerItems.Any(p => p.Id == id);
        }

        private static PlayerDTO PlayerToDTO(Player playerItem) =>
            new PlayerDTO
            {
                Id = playerItem.Id,
                NickName = playerItem.NickName,
                FirstName = playerItem.FirstName,
                LastName = playerItem.LastName,
                Email = playerItem.Email,
                NumberOfPoints = playerItem.NumberOfPoints,
                NumberOfCredits = playerItem.NumberOfCredits,
                Badges = playerItem.Badges
            };
    }
}
